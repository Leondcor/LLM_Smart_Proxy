#!/usr/bin/env python3
"""
脱敏 CLI 工具 — 独立使用，双重校验
支持文件/文本输入，交互式审查，输出脱敏报告
支持格式: .txt .md .json .csv .log .docx .pdf

用法:
  # 文件脱敏（自动检测格式）
  python sanitize.py input.txt
  python sanitize.py input.docx
  python sanitize.py input.pdf

  # 输出到文件
  python sanitize.py input.txt -o sanitized.txt
  python sanitize.py input.docx -o sanitized.docx

  # 交互式逐条确认
  python sanitize.py input.txt --interactive

  # 管道输入
  echo "深圳西井科技报价 328万元" | python sanitize.py

  # 脱敏报告
  python sanitize.py input.txt --report

  # 预检模式：扫描文件/目录，询问是否继续
  python sanitize.py --preflight 投标文件目录/

  # 自定义规则
  python sanitize.py input.txt --rules my_rules.yaml
"""
import argparse
import sys
import os
import json
import re
from datetime import datetime

# 确保能导入同目录模块
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sanitizer_engine import (
    load_rules, sanitize_text, sanitize_messages,
    log_mapping, sanitize_summary, compile_entities,
    _protect_whitelist, _restore_whitelist, _apply_strategy,
)

# ── 终端颜色 ──
RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
CYAN = "\033[96m"
BOLD = "\033[1m"
RESET = "\033[0m"


def read_input(path=None):
    """读取输入：文件路径 或 stdin"""
    if path:
        if not os.path.exists(path):
            print(f"{RED}错误: 文件不存在: {path}{RESET}")
            sys.exit(1)
        with open(path, "r", encoding="utf-8") as f:
            return f.read()

    # stdin
    if not sys.stdin.isatty():
        return sys.stdin.read()

    print(f"{RED}错误: 未提供输入。用法: python sanitize.py <文件> 或 管道输入{RESET}")
    sys.exit(1)


def write_output(text, path=None):
    """写入输出"""
    if path:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        print(f"{GREEN}✓ 已保存: {path}{RESET}")
    else:
        # 确保 UTF-8 编码输出
        sys.stdout.reconfigure(encoding="utf-8") if hasattr(sys.stdout, "reconfigure") else None
        print(text)


def interactive_review(text, rules_config):
    """交互式脱敏：逐项展示，用户逐条确认"""
    entities = compile_entities(rules_config.get("entities", []))
    whitelist_terms = rules_config.get("whitelist", {}).get("terms", [])

    text_work, protected = _protect_whitelist(text, whitelist_terms)

    all_matches = []
    counter_state = {}

    # 收集所有匹配
    for entity in entities:
        eid = entity["id"]
        if eid not in counter_state:
            counter_state[eid] = {"idx": 0}

        for rule in entity["rules"]:
            regex = rule["regex"]
            min_len = rule.get("min_length", 0)
            exclude_pat = rule.get("exclude_pattern")

            for m in regex.finditer(text_work):
                matched = m.group(0)
                if min_len > 0 and len(matched) < min_len:
                    continue
                if exclude_pat and re.search(exclude_pat, matched):
                    continue
                all_matches.append({
                    "entity": entity,
                    "start": m.start(),
                    "end": m.end(),
                    "original": matched,
                })

    # 按位置排序
    all_matches.sort(key=lambda x: x["start"])

    if not all_matches:
        print(f"{GREEN}✓ 未检出敏感信息{RESET}")
        return text

    print(f"\n{CYAN}{'='*60}{RESET}")
    print(f"{BOLD}交互式脱敏审查 — 共 {len(all_matches)} 处候选{RESET}")
    print(f"{CYAN}{'='*60}{RESET}\n")

    replacements = []
    approved = 0
    skipped = 0

    for i, match in enumerate(all_matches, 1):
        entity = match["entity"]
        eid = entity["id"]
        original = match["original"]

        # 显示上下文
        ctx_start = max(0, match["start"] - 20)
        ctx_end = min(len(text_work), match["end"] + 20)
        ctx = text_work[ctx_start:ctx_end]
        ctx = ctx.replace(original, f"{RED}{BOLD}{original}{RESET}")
        if ctx_start > 0:
            ctx = "…" + ctx
        if ctx_end < len(text_work):
            ctx = ctx + "…"

        print(f"[{i}/{len(all_matches)}] {YELLOW}{entity['name']}{RESET}")
        print(f"  上下文: {ctx}")
        print(f"  原文:   {RED}{original}{RESET}")

        # 计算替换文本
        default_replacement = _apply_strategy(entity, original, counter_state[eid])

        choice = input(f"  替换为 [{default_replacement}]? (y=确认 / n=跳过 / 自定义文本): ").strip()

        if choice.lower() == "n" or choice.lower() == "no":
            skipped += 1
            print(f"  {YELLOW}→ 跳过{RESET}\n")
            continue
        elif choice == "" or choice.lower() == "y" or choice.lower() == "yes":
            replacement = default_replacement
        else:
            replacement = choice

        replacements.append({
            "entity": eid,
            "entity_name": entity["name"],
            "original": original,
            "replaced": replacement,
            "position": match["start"],
            "length": match["end"] - match["start"],
        })
        approved += 1
        print(f"  {GREEN}→ {replacement}{RESET}\n")

    # 执行替换
    for r in reversed(replacements):
        text_work = text_work[:r["position"]] + r["replaced"] + text_work[r["position"] + r["length"]:]

    text_work = _restore_whitelist(text_work, protected)

    print(f"\n{CYAN}审查完成: {GREEN}确认 {approved} 处{RESET}, {YELLOW}跳过 {skipped} 处{RESET}")
    log_mapping(replacements, rules_config, source="cli-interactive")
    return text_work


def auto_sanitize(text, rules_config, verbose=True):
    """自动脱敏（非交互）"""
    sanitized, replacements = sanitize_text(text, rules_config)

    if verbose and replacements:
        summary = sanitize_summary(replacements)
        print(f"{CYAN}[脱敏] {summary}{RESET}")

    log_mapping(replacements, rules_config, source="cli-auto")
    return sanitized, replacements


def show_report(replacements, rules_config):
    """显示脱敏报告"""
    if not replacements:
        print(f"{GREEN}✓ 未检出敏感信息{RESET}")
        return

    print(f"\n{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}脱敏报告 — {len(replacements)} 处替换{RESET}")
    print(f"{BOLD}{'='*60}{RESET}\n")

    by_entity = {}
    for r in replacements:
        eid = r["entity"]
        if eid not in by_entity:
            by_entity[eid] = {"name": r["entity_name"], "items": []}
        by_entity[eid]["items"].append(r)

    for eid, info in sorted(by_entity.items(), key=lambda x: -len(x[1]["items"])):
        print(f"{YELLOW}▸ {info['name']} ({len(info['items'])}处){RESET}")
        for r in info["items"]:
            orig = r["original"]
            if len(orig) > 60:
                orig = orig[:57] + "..."
            print(f"    {RED}{orig}{RESET} → {GREEN}{r['replaced']}{RESET}")

    print(f"\n{CYAN}映射日志: {rules_config.get('settings', {}).get('mapping_log', '未配置')}{RESET}")


def do_preflight(input_path, rules_config):
    """
    预检模式：扫描文件或目录，显示检出的敏感信息，
    然后询问用户是否继续。
    用于在开启代理会话前的安全检查。
    """
    import glob as globmod

    # 收集要扫描的文件
    files_to_scan = []
    if input_path:
        if os.path.isfile(input_path):
            files_to_scan = [input_path]
        elif os.path.isdir(input_path):
            # 扫描目录中常见文档类型
            exts = {".txt", ".md", ".json", ".yaml", ".yml", ".xml",
                    ".csv", ".log", ".pdf", ".docx", ".xlsx"}
            for root, dirs, filenames in os.walk(input_path):
                # 跳过隐藏目录和 node_modules
                dirs[:] = [d for d in dirs if not d.startswith(".") and d != "node_modules"]
                for fname in filenames:
                    _, ext = os.path.splitext(fname)
                    if ext.lower() in exts:
                        files_to_scan.append(os.path.join(root, fname))
        else:
            print(f"{RED}错误: 路径不存在: {input_path}{RESET}")
            sys.exit(1)

    if not files_to_scan:
        print(f"{YELLOW}未找到可扫描的文件（txt/md/json/yaml/xml/csv/log）{RESET}")
        return

    print(f"\n{BOLD}{'='*60}{RESET}")
    print(f"{BOLD}预检扫描 — {len(files_to_scan)} 个文件{RESET}")
    print(f"{'='*60}\n")

    # 扫描每个文件
    all_reps = []
    file_results = {}

    for fpath in files_to_scan:
        try:
            with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except Exception as e:
            print(f"  {YELLOW}跳过 {os.path.basename(fpath)}: {e}{RESET}")
            continue

        if len(content) < 10:
            continue

        _, reps = auto_sanitize(content, rules_config, verbose=False)
        if reps:
            file_results[fpath] = reps
            all_reps.extend(reps)

    if not all_reps:
        print(f"{GREEN}✓ 未检出敏感信息 — 可以安全使用{RESET}\n")
        return

    # 汇总显示
    by_entity = {}
    for r in all_reps:
        eid = r["entity"]
        if eid not in by_entity:
            by_entity[eid] = {"name": r["entity_name"], "count": 0, "samples": []}
        by_entity[eid]["count"] += 1
        if len(by_entity[eid]["samples"]) < 3:
            by_entity[eid]["samples"].append(r["original"][:50])

    print(f"{YELLOW}⚠ 检出 {len(all_reps)} 处敏感信息{RESET}\n")
    for eid, info in sorted(by_entity.items(), key=lambda x: -x[1]["count"]):
        print(f"  {RED}{info['name']}{RESET} ×{info['count']}")
        for s in info["samples"]:
            print(f"    → {s}")

    # 按文件显示
    print(f"\n{CYAN}涉及文件:{RESET}")
    for fpath, reps in sorted(file_results.items()):
        short = os.path.relpath(fpath, input_path if os.path.isdir(input_path) else os.path.dirname(input_path))
        entities_in_file = set(r["entity_name"] for r in reps)
        print(f"  {short} — {', '.join(entities_in_file)} ({len(reps)}处)")

    # 询问
    print(f"\n{BOLD}{'─'*40}{RESET}")
    while True:
        choice = input(f"{YELLOW}发现敏感信息。是否仍要使用此上下文进行模型调用? (y/n/q): {RESET}").strip().lower()
        if choice in ("y", "yes"):
            print(f"{GREEN}→ 已确认，请继续使用模型。建议开启代理脱敏 (X-Sanitize-Mode: auto){RESET}")
            print(f"{CYAN}  代理安全端口: http://localhost:4002/v1/chat/completions{RESET}")
            break
        elif choice in ("n", "no"):
            print(f"{RED}→ 已取消。请先脱敏处理文件后再使用模型。{RESET}")
            print(f"{CYAN}  快速脱敏: python sanitize.py {input_path} --interactive{RESET}")
            sys.exit(1)
        elif choice in ("q", "quit"):
            print("→ 退出")
            sys.exit(0)
        else:
            print(f"{RED}请输入 y(是) / n(否) / q(退出){RESET}")

    # 记录预检日志
    log_mapping(all_reps, rules_config, source="preflight")


def _handle_docx(args, rules_config):
    """DOCX 脱敏处理流程"""
    from docx_handler import sanitize_docx

    # 输出路径
    if args.output:
        out_path = args.output
    else:
        base, ext = os.path.splitext(args.input)
        out_path = f"{base}_sanitized{ext}"

    print(f"{CYAN}[DOCX] 解析中...{RESET}")
    stats = sanitize_docx(args.input, out_path, rules_config)

    if not stats.get('success'):
        print(f"{RED}错误: DOCX 处理失败: {stats.get('error', '未知错误')}{RESET}")
        sys.exit(1)

    # ── 汇总输出 ──
    print(f"\n{GREEN}✓ 脱敏完成: {out_path}{RESET}")
    print(f"{CYAN}──────────────────────────────────{RESET}")
    print(f"  文档字符数:       {stats['docx_text_chars']}")
    print(f"  修改的 XML 文件:  {stats['changed_xml_files']}")
    if stats['changed_xml_names']:
        for name in stats['changed_xml_names']:
            print(f"    - {name}")

    # 段落
    if stats['paragraphs_changed'] > 0:
        print(f"\n  {YELLOW}▸ 段落脱敏{RESET}")
        print(f"    段落修改数: {stats['paragraphs_changed']}")
        print(f"    命中次数:   {stats['paragraph_hits']}")

    # 表格
    if stats['table_cells_changed'] > 0:
        print(f"\n  {YELLOW}▸ 表格脱敏{RESET}")
        print(f"    单元格修改: {stats['table_cells_changed']}")
        if stats['context_email']:    print(f"    - 邮箱列: {stats['context_email']}")
        if stats['context_phone']:    print(f"    - 电话列: {stats['context_phone']}")
        if stats['context_name']:     print(f"    - 姓名列: {stats['context_name']}")
        if stats['context_id']:       print(f"    - ID/编号列: {stats['context_id']}")
        if stats['context_amount']:   print(f"    - 金额列: {stats['context_amount']}")
        if stats['context_address']:  print(f"    - 地址列: {stats['context_address']}")
        if stats['long_num']:         print(f"    - 长数字(无上下文): {stats['long_num']}")

    print(f"\n  {BOLD}总命中: {stats['total_hits']} 处{RESET}")

    # ── 生成报告文件 ──
    if args.report or True:  # DOCX 默认生成报告
        report_path = os.path.splitext(out_path)[0] + "_report.txt"
        _write_docx_report(report_path, stats)
        print(f"{CYAN}  报告: {report_path}{RESET}")

    if stats['total_hits'] == 0:
        print(f"\n{YELLOW}⚠ 未检出敏感信息，请确认文件内容是否正确{RESET}")

    return stats


def _handle_pdf(args, rules_config):
    """PDF 脱敏处理流程"""
    from pdf_handler import sanitize_pdf_pages, write_sanitized_txt, write_sanitized_pdf, write_pdf_report

    # 输出路径
    if args.output:
        base, _ = os.path.splitext(args.output)
        out_txt = base + '_sanitized.txt'
        out_pdf = base + '_sanitized.pdf'
    else:
        base, _ = os.path.splitext(args.input)
        out_txt = base + '_sanitized.txt'
        out_pdf = base + '_sanitized.pdf'

    report_path = base + '_sanitized_report.txt'

    print(f"{CYAN}[PDF] 解析中...{RESET}")
    ok, raw_pages, sanitized_pages, stats, err = sanitize_pdf_pages(args.input, rules_config)

    if not ok:
        print(f"{RED}错误: PDF 处理失败: {err}{RESET}")
        sys.exit(1)

    # 写文本文件（主输出）
    write_sanitized_txt(sanitized_pages, out_txt)
    print(f"{GREEN}✓ 文本文件: {out_txt}{RESET}")

    # 尝试写 PDF
    pdf_ok, pdf_err = write_sanitized_pdf(sanitized_pages, out_pdf)
    if pdf_ok:
        print(f"{GREEN}✓ PDF 文件: {out_pdf}{RESET}")
    else:
        print(f"{YELLOW}⚠ 无法生成 PDF: {pdf_err}{RESET}")

    # 写报告
    write_pdf_report(report_path, stats)
    print(f"{CYAN}  报告: {report_path}{RESET}")

    # 汇总
    print(f"\n{GREEN}✓ 脱敏完成{RESET}")
    print(f"{CYAN}──────────────────────────────────{RESET}")
    print(f"  总页数:       {stats['total_pages']}")
    print(f"  含敏感信息页: {stats['pages_with_hits']}")
    for k, v in stats['by_type'].items():
        if v > 0:
            label = {'email': '邮箱', 'phone': '电话', 'id': '证件号', 'amount': '金额'}.get(k, k)
            print(f"  {label}: {v}")
    print(f"\n  {BOLD}总命中: {stats['total_hits']} 处{RESET}")

    if stats['total_hits'] == 0:
        print(f"\n{YELLOW}⚠ 未检出敏感信息，请确认文件内容是否正确{RESET}")

    return stats


def _write_docx_report(report_path, stats):
    """生成 DOCX 脱敏报告文件"""
    lines = [
        "=" * 50,
        f"DOCX 脱敏报告",
        f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "=" * 50,
        "",
        f"文档字符数:       {stats['docx_text_chars']}",
        f"修改的 XML 文件:  {stats['changed_xml_files']}",
    ]
    if stats['changed_xml_names']:
        lines.append(f"文件列表:")
        for n in stats['changed_xml_names']:
            lines.append(f"  - {n}")

    lines += [
        "",
        "--- 段落 ---",
        f"修改段落数: {stats['paragraphs_changed']}",
        f"命中次数:   {stats['paragraph_hits']}",
        "",
        "--- 表格 ---",
        f"修改单元格: {stats['table_cells_changed']}",
        f"  邮箱列:   {stats['context_email']}",
        f"  电话列:   {stats['context_phone']}",
        f"  姓名列:   {stats['context_name']}",
        f"  ID列:     {stats['context_id']}",
        f"  金额列:   {stats['context_amount']}",
        f"  地址列:   {stats['context_address']}",
        f"  长数字:   {stats['long_num']}",
        "",
        f"总命中: {stats['total_hits']} 处",
        f"处理结果: {'成功' if stats['success'] else '失败'}",
    ]

    with open(report_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


def main():
    parser = argparse.ArgumentParser(
        description="LLM Smart Proxy — 脱敏 CLI 工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python sanitize.py 投标文件.txt                    # 自动脱敏，输出到终端
  python sanitize.py 投标文件.txt -o 脱敏版.txt      # 保存到文件
  python sanitize.py 投标文件.txt --interactive       # 逐条审查确认
  python sanitize.py 投标文件.txt --report            # 显示脱敏报告（不修改）
  echo "报价328万" | python sanitize.py               # 管道输入
  python sanitize.py input.json --json                # JSON 消息格式输入
        """
    )

    parser.add_argument("input", nargs="?", help="输入文件路径（省略则从 stdin 读取）")
    parser.add_argument("-o", "--output", help="输出文件路径")
    parser.add_argument("-r", "--rules", help="自定义规则文件路径（默认 sanitizer_rules.yaml）")
    parser.add_argument("-i", "--interactive", action="store_true", help="交互式审查模式")
    parser.add_argument("--report", action="store_true", help="仅显示脱敏报告，不输出脱敏后文本")
    parser.add_argument("--preflight", action="store_true", help="预检模式：扫描文件/目录，显示检出内容并询问是否继续")
    parser.add_argument("--json", action="store_true", help="输入为 JSON 格式（chat messages）")
    parser.add_argument("-q", "--quiet", action="store_true", help="静默模式，不输出摘要")
    parser.add_argument("--no-log", action="store_true", help="不记录映射日志")

    args = parser.parse_args()

    # 加载规则
    rules_path = args.rules
    try:
        rules_config = load_rules(rules_path)
    except Exception as e:
        print(f"{RED}错误: 无法加载规则文件: {e}{RESET}")
        sys.exit(1)

    if args.no_log:
        rules_config["settings"]["log_mapping"] = False

    # ── 格式分流 ──
    if args.input and args.input.lower().endswith('.docx'):
        return _handle_docx(args, rules_config)

    if args.input and args.input.lower().endswith('.pdf'):
        return _handle_pdf(args, rules_config)

    # 读取输入（文本格式）
    raw = read_input(args.input)

    if args.preflight:
        do_preflight(args.input, rules_config)
        return

    if args.json:
        # JSON 格式（messages 数组）
        try:
            data = json.loads(raw)
            data, replacements, file_reports = sanitize_messages(data, rules_config)
            output_text = json.dumps(data, ensure_ascii=False, indent=2)
        except json.JSONDecodeError as e:
            print(f"{RED}错误: JSON 解析失败: {e}{RESET}")
            sys.exit(1)
    else:
        # 纯文本
        if args.interactive:
            output_text = interactive_review(raw, rules_config)
            # 交互模式已处理日志，跳过
            if args.report:
                print(f"\n{GREEN}交互模式下报告已实时展示，无需 --report{RESET}")
            if args.output:
                write_output(output_text, args.output)
            return
        else:
            output_text, replacements = auto_sanitize(raw, rules_config, verbose=not args.quiet)

    # 输出（先写文件）
    write_output(output_text, args.output)

    # 报告模式（写文件后展示报告）
    if args.report:
        show_report(replacements, rules_config)


if __name__ == "__main__":
    main()
