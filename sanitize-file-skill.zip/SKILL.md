---
name: sanitize-file
description: >
  文件脱敏工具。当用户说"帮我把这个文件脱敏"、"脱敏 XX 文件"、"sanitize this file"、
  或 "@引用文件 脱敏" 等类似话术时触发。自动调用 sanitize.py 对目标文件中的敏感信息
  （人名、手机号、邮箱、身份证、金额、公司名、地址等）进行识别和替换，生成脱敏副本并输出对比报告。
  支持 .txt .md .json .csv .log .docx .pdf 格式。
agent_created: true
---

# 文件脱敏 Skill

## 触发条件

用户消息中包含以下任一模式时触发：
- "脱敏" + 文件引用或文件路径
- "sanitize" + 文件引用或文件路径
- "敏感信息处理" / "去标识化" + 文件引用
- "@文件 脱敏" / "@文件 帮我脱敏"

## 支持的文件格式

| 格式 | 处理方式 | 说明 |
|------|---------|------|
| .txt .md .json .csv .log .yaml .xml | 文本正则引擎 | 全文 pattern 匹配脱敏 |
| .docx | ZIP/XML 解析 + 表格上下文 | 段落用正则引擎，表格按表头上下文智能脱敏 |
| .pdf | pypdf 提取文字 + 正则引擎 | 逐页提取文本脱敏，输出 .txt + .pdf（可选） |

## 工作流

### Step 1: 确认目标文件

从用户消息中提取文件路径。优先级：
1. `@` 引用的文件（消息中会携带绝对路径）
2. 用户明确写出的路径
3. 若无法确定文件，反问用户确认

### Step 2: 读取原文件

先读取目标文件内容，确认文件存在且内容非空。

### Step 3: 运行 sanitize.py

sanitize.py 位置：skill 目录下的 `scripts/sanitize.py`

命令格式：
```bash
python ~/.workbuddy/skills/sanitize-file/scripts/sanitize.py <输入文件> -o <输入文件_目录>_sanitized.<扩展名> --report
```

- 输出文件命名规则：原文件名 + `_sanitized`，放在同一目录
- 必须加 `--report` 以生成脱敏报告
- **自动检测文件格式**：`.docx` 走 ZIP/XML 解析 + 表格上下文，`.pdf` 走 pypdf 文本提取 + 正则引擎，无需额外参数

Python 运行环境：优先使用 venv（`~/.workbuddy/binaries/python/envs/default/Scripts/python.exe`），
如不可用则使用系统 Python（需 `pip install pyyaml`）。

### Step 4: 读取并展示结果

运行完成后：
1. 读取脱敏后的文件
2. 对比原文件和脱敏文件，生成摘要表格
3. 向用户展示：
   - 处理了多少条敏感信息
   - 每类敏感信息的替换数量（表格形式）
   - 脱敏文件路径
   - 询问是否需要进一步调整规则

### Step 5: 规则调整（可选）

如果用户对脱敏结果不满意：
- 编辑 skill 目录下的 `scripts/sanitizer_rules.yaml` 调整规则
- 重新运行 sanitize.py
- 重复 Step 4

## DOCX 脱敏原理

DOCX 本质是 ZIP 压缩包，内含多个 XML 文件。

1. **段落文本** — 从 `word/document.xml` 等提取 `w:p` 段落文本，复用正则引擎脱敏
2. **表格数据** — 从 `w:tbl` 提取表格，先分析表头/左侧标签列确定上下文类型
   （姓名、电话、邮箱、ID、金额、地址），再按列整格脱敏，避免盲目替换所有数字造成误伤
3. 脱敏后的 XML 重新打包为新的 .docx

表格上下文检测支持中英文标签，例如：
- 姓名列: "姓名"、"联系人"、"Name"、"Contact Person"
- 电话列: "电话"、"手机"、"Phone"、"Mobile"
- 邮箱列: "邮箱"、"Email"、"E-mail"
- ID列: "编号"、"账号"、"ID"、"Account"、"Contract No"
- 金额列: "金额"、"报价"、"Amount"、"Price"
- 地址列: "地址"、"Address"、"Location"

## PDF 脱敏原理

PDF 处理流程：

1. **文本提取** — 用 `pypdf` 逐页提取文本（纯文字层，不支持扫描件）
2. **逐页脱敏** — 每页文本调用 `sanitizer_engine.sanitize_text()` 复用 YAML 规则
3. **双输出** — 同时生成脱敏 .txt（内容最完整）和 .pdf（需 `reportlab`，保留分页）
4. **逐页报告** — 记录每页命中次数和类型

限制：
- 扫描件（无文本层）需先 OCR，本工具不支持
- 输出 PDF 会丢失原排版/字体/图片，仅保留纯文字
- **推荐优先使用 .txt 输出**，内容最完整

## 注意事项

- 默认不覆盖原文件，始终生成新副本
- 如果输出文件已存在，询问用户是否覆盖
- sanitize.py 依赖 `sanitizer_engine.py`、`docx_handler.py`、`pdf_handler.py` 和 `sanitizer_rules.yaml`（同目录），确保这些文件存在
- 如果用户说"直接覆盖原文件"，需要二次确认
- DOCX 表格脱敏依赖表头/标签列的准确命名，如表格结构不规范可能漏脱敏
- PDF 脱敏需安装 `pypdf`（必装）和 `reportlab`（可选，用于输出 PDF 格式）
