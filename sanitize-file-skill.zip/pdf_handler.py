#!/usr/bin/env python3
"""
PDF 脱敏处理器 — pypdf 提取文本 + sanitizer_engine 脱敏

工作流:
  1. pypdf 提取每页文本
  2. 逐页调用 sanitizer_engine.sanitize_text() 脱敏（复用 YAML 规则）
  3. 输出脱敏后文本文件（.txt，保留页码分隔）
  4. 若安装了 reportlab，同时输出格式化 PDF
  5. 生成脱敏报告

限制:
  - 扫描件（无文本层）需先 OCR（未实现）
  - 输出 PDF 会丢失原排版/图片/字体，仅保留文字内容
  - 推荐用 .txt 输出，内容最完整
"""

import re
import sys
import os
from pathlib import Path

try:
    from pypdf import PdfReader
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False


# ── 轻量统计正则（仅用于报告，不参与脱敏）────────────

EMAIL_RE = re.compile(r'[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+')

PHONE_CN_RE = re.compile(r'(?:\+86\s?)?1[3-9]\d{9}')

ID_CN_RE = re.compile(r'\b\d{17}[\dXx]\b')

USCC_RE = re.compile(r'\b[A-Za-z0-9]{18}\b')

AMOUNT_RE = re.compile(
    r'[¥$€£]?\s*\d[\d,.]*(?:\s*[万千百十]?[元块万]|\s*[KkMmBb])?'
)


def count_hits(text):
    """统计一段文本里各类敏感信息命中次数（用于报告）"""
    return {
        'email': len(EMAIL_RE.findall(text)),
        'phone': len(PHONE_CN_RE.findall(text)),
        'id':    max(len(ID_CN_RE.findall(text)),
                      len(USCC_RE.findall(text))),
        'amount': len(AMOUNT_RE.findall(text)),
    }


def sanitize_pdf_pages(src_path, rules_config):
    """
    提取 PDF 文本并逐页脱敏（调用 sanitizer_engine）。
    返回: (成功?, [原始文本页], [脱敏文本页], stats_dict, 错误信息)
    """
    if not HAS_PYPDF:
        return False, None, None, None, 'pypdf 未安装，请运行: pip install pypdf'

    src = Path(src_path)
    if not src.exists():
        return False, None, None, None, f'源文件不存在: {src}'

    try:
        from sanitizer_engine import sanitize_text as se_sanitize
    except ImportError:
        se_sanitize = None

    try:
        reader = PdfReader(str(src))
        total_pages = len(reader.pages)

        raw_pages = []
        sanitized_pages = []
        stats = {
            'total_pages': total_pages,
            'pages_with_hits': 0,
            'total_hits': 0,
            'by_type': {'email': 0, 'phone': 0, 'id': 0, 'amount': 0},
            'page_details': [],
        }

        for i, page in enumerate(reader.pages):
            try:
                text = page.extract_text() or ''
            except Exception:
                text = ''

            raw_pages.append(text)

            if se_sanitize:
                sanitized, replacements = se_sanitize(text, rules_config)
                hit_count = len(replacements) if replacements else 0
            else:
                # fallback: 用轻量正则
                sanitized = text
                hits = count_hits(text)
                hit_count = sum(hits.values())
                if hit_count > 0:
                    sanitized = EMAIL_RE.sub('[邮箱已脱敏]', sanitized)
                    sanitized = PHONE_CN_RE.sub('[电话已脱敏]', sanitized)
            sanitized_pages.append(sanitized)

            if hit_count > 0:
                stats['pages_with_hits'] += 1
                stats['total_hits'] += hit_count
                hits = count_hits(text)
                for k in stats['by_type']:
                    stats['by_type'][k] += hits.get(k, 0)
                stats['page_details'].append({
                    'page': i + 1,
                    'hits': hits,
                    'modified': sanitized != text,
                })
            else:
                stats['page_details'].append({
                    'page': i + 1,
                    'hits': {},
                    'modified': False,
                })

        return True, raw_pages, sanitized_pages, stats, None

    except Exception as e:
        return False, None, None, None, str(e)


def write_sanitized_txt(sanitized_pages, output_path):
    """把脱敏后的文本页写入 .txt 文件"""
    with open(output_path, 'w', encoding='utf-8') as f:
        for i, page_text in enumerate(sanitized_pages):
            if i > 0:
                f.write('\n\n' + '=' * 50 + '\n')
                f.write(f'第 {i + 1} 页\n')
                f.write('=' * 50 + '\n\n')
            f.write(page_text)


def write_sanitized_pdf(sanitized_pages, output_path):
    """
    把脱敏后的文本页写入 PDF（需要 reportlab）。
    返回: (成功?, 错误信息)
    """
    try:
        from reportlab.platypus import SimpleDocTemplate, Paragraph, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont

        # 注册中文字体
        font_registered = False
        font_paths = [
            'C:/Windows/Fonts/simhei.ttf',
            'C:/Windows/Fonts/simsun.ttc',
            'C:/Windows/Fonts/msyh.ttc',
            'C:/Windows/Fonts/simkai.ttf',
        ]
        for fp in font_paths:
            if os.path.exists(fp):
                try:
                    pdfmetrics.registerFont(TTFont('ChineseFont', fp))
                    font_registered = True
                    break
                except Exception:
                    pass

        doc = SimpleDocTemplate(str(output_path))
        styles = getSampleStyleSheet()
        if font_registered:
            try:
                styles['Normal'].fontName = 'ChineseFont'
                styles['Normal'].fontSize = 10
                styles['Normal'].leading = 16
            except Exception:
                pass

        story = []
        for i, page_text in enumerate(sanitized_pages):
            if i > 0:
                story.append(PageBreak())
            for line in page_text.split('\n'):
                if line.strip():
                    try:
                        story.append(Paragraph(line, styles['Normal']))
                    except Exception:
                        story.append(Paragraph(line or ' ', styles['Normal']))

        doc.build(story)
        return True, None

    except ImportError:
        return False, 'reportlab 未安装，请运行: pip install reportlab'
    except Exception as e:
        return False, str(e)


def write_pdf_report(output_path, stats):
    """生成 PDF 脱敏报告文件"""
    lines = [
        '=' * 50,
        'PDF 脱敏报告',
        f"生成时间: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        '=' * 50,
        '',
        f"总页数:         {stats['total_pages']}",
        f"含敏感信息页:   {stats['pages_with_hits']}",
        f"总命中:           {stats['total_hits']} 处",
        '',
        '--- 按类型统计 ---',
    ]

    type_labels = {'email': '邮箱', 'phone': '电话', 'id': '证件号', 'amount': '金额'}
    for k, v in stats['by_type'].items():
        if v > 0:
            lines.append(f'  {type_labels.get(k, k)}: {v}')

    lines += ['', '--- 按页详情 ---']
    for detail in stats['page_details']:
        if detail['modified']:
            hit_str = ', '.join(f'{k}={v}' for k, v in detail['hits'].items() if v > 0)
            lines.append(f"  第 {detail['page']} 页: {hit_str}")
        else:
            lines.append(f"  第 {detail['page']} 页: 无敏感信息")

    lines += ['', f"处理结果: {'成功' if stats['total_hits'] > 0 else '未检出敏感信息'}"]

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('用法: python pdf_handler.py <input.pdf> [output.txt]')
        sys.exit(1)

    src = sys.argv[1]
    base, _ = os.path.splitext(src)
    txt_out = sys.argv[2] if len(sys.argv) > 2 else base + '_sanitized.txt'
    pdf_out = base + '_sanitized.pdf'
    report_out = base + '_sanitized_report.txt'

    print(f'PDF 脱敏处理: {src}')
    ok, _, sanitized, stats, err = sanitize_pdf_pages(src, None)

    if not ok:
        print(f'错误: {err}')
        sys.exit(1)

    # 写文本文件
    write_sanitized_txt(sanitized, txt_out)
    print(f'✓ 文本文件: {txt_out}')

    # 尝试写 PDF
    pdf_ok, pdf_err = write_sanitized_pdf(sanitized, pdf_out)
    if pdf_ok:
        print(f'✓ PDF 文件: {pdf_out}')
    else:
        print(f'⚠ 无法生成 PDF: {pdf_err}')
        print(f'  已生成文本文件: {txt_out}')

    # 写报告
    write_pdf_report(report_out, stats)
    print(f'✓ 报告: {report_out}')

    print(f"\n总页数: {stats['total_pages']}")
    print(f"含敏感信息页: {stats['pages_with_hits']}")
    print(f"总命中: {stats['total_hits']}")
    for k, v in stats['by_type'].items():
        if v > 0:
            print(f'  {k}: {v}')
