#!/usr/bin/env python3
"""
DOCX 脱敏处理器 — ZIP/XML 解析 + 表格上下文智能脱敏

设计原则:
  - 段落: 复用 sanitizer_engine 正则引擎，全文匹配脱敏
  - 表格: 先检测表头/标签列确定上下文类型，再按列整格脱敏
    避免盲目替换所有数字/英文造成误伤（如数量、日期、页码）
"""

import re
import io
import zipfile
import shutil
from lxml import etree as ET
from pathlib import Path

# XML 命名空间
NS_W = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
NS_R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'
NS_MC = 'http://schemas.openxmlformats.org/markup-compatibility/2006'

# ─────────────────────────────────────────────
#  表格上下文标签检测
# ─────────────────────────────────────────────

# 注意: 匹配顺序很重要，NAME 里的 "project manager" 不要被 ID 里的 "number" 抢走
LABEL_RULES = [
    ('email',  re.compile(
        r'(?i)\b(e-?mail|电子邮件|电子邮箱|邮箱)\b'
    )),
    ('phone',  re.compile(
        r'(?i)\b(电话|手机|传真|联系方式|联系电话|phone|mobile|tel|telephone|cell|fax|contact\s*number)\b'
    )),
    ('name',   re.compile(
        r'(?i)\b(name|full\s*name|姓名|联系人|代表|负责人|项目经理|法人|授权人|签约人|'
        r'contact\s*person|representative|project\s*manager|personnel)\b'
    )),
    ('id',     re.compile(
        r'(?i)\b(编号|账号|代码|税号|登记号|注册号|许可证|身份证号|统一社会信用代码|'
        r'id|identity|passport|ssn|ein|tax\s*id|vat|duns|uei|registration|license|'
        r'account|iban|swift|bic|contract\s*no|tender\s*no|number|no\.|code)\b'
    )),
    ('amount', re.compile(
        r'(?i)\b(金额|报价|价格|预算|费用|总价|投标价|中标价|合同金额|'
        r'amount|price|bid\s*price|quotation|budget|cost|fee|total)\b'
    )),
    ('address', re.compile(
        r'(?i)\b(地址|所在地|办公地点|注册地址|address|location|headquarters|office)\b'
    )),
]


def detect_context(label_text):
    """根据标签文本返回上下文类型: email|phone|name|id|amount|address|None"""
    if not label_text:
        return None
    for ctx_type, regex in LABEL_RULES:
        if regex.search(label_text):
            return ctx_type
    return None


# ─────────────────────────────────────────────
#  XML 文本读写 (w:t 元素)
# ─────────────────────────────────────────────

def get_text(elem):
    """从 XML 元素提取所有 w:t 子元素的纯文本"""
    parts = []
    for t in elem.iter(f'{{{NS_W}}}t'):
        if t.text:
            parts.append(t.text)
    return ''.join(parts)


def set_text(elem, text):
    """将文本写入 XML 元素: 全部塞进第一个 w:t，清空其余"""
    t_elems = list(elem.iter(f'{{{NS_W}}}t'))
    if not t_elems:
        return False
    t_elems[0].text = text
    for t in t_elems[1:]:
        t.text = ''
    return True


# ─────────────────────────────────────────────
#  表格上下文脱敏
# ─────────────────────────────────────────────

def force_by_context(text, context_type):
    """根据列上下文强制脱敏整格文本，返回 (new_text, changed)"""
    if not text or not text.strip():
        return text, False

    s = text.strip()

    if context_type == 'email':
        if '@' in s:
            parts = s.split('@')
            if len(parts) == 2 and len(parts[0]) > 1:
                return parts[0][:2] + '***@' + parts[1], True

    elif context_type == 'phone':
        # 保留非数字字符（括号、横线等），只替换数字
        digits = re.sub(r'\D', '', s)
        if len(digits) >= 7:
            return re.sub(r'\d', '*', s), True

    elif context_type == 'name':
        if re.search(r'[\u4e00-\u9fff]', s):
            chars = list(s)
            if len(chars) >= 2:
                return chars[0] + '*' * (len(chars) - 1), True
        else:
            # 英文名
            parts = s.split()
            if len(parts) >= 2:
                masked = []
                for p in parts:
                    if len(p) > 1:
                        masked.append(p[0] + '*' * (len(p) - 1))
                    else:
                        masked.append(p)
                return ' '.join(masked), True
            elif len(s) > 2:
                return s[:1] + '*' * (len(s) - 1), True

    elif context_type == 'id':
        # 保留头尾少量字符
        clean = s
        if len(clean) >= 6:
            return clean[:2] + '*' * (len(clean) - 4) + clean[-2:], True
        elif len(clean) >= 2:
            return clean[:1] + '*' * (len(clean) - 1), True

    elif context_type == 'amount':
        # 保留非数字字符，替换数字
        if re.search(r'\d', s):
            return re.sub(r'\d', '#', s), True

    elif context_type == 'address':
        if len(s) > 3:
            return s[:2] + '*' * (len(s) - 2), True

    return text, False


def process_table(tbl_elem):
    """处理单个表格: 检测表头→按列脱敏。返回 stats dict"""
    stat = {k: 0 for k in [
        'table_cells_changed', 'context_email', 'context_phone',
        'context_name', 'context_id', 'context_amount',
        'context_address', 'long_num'
    ]}

    rows = tbl_elem.findall(f'{{{NS_W}}}tr')
    if len(rows) < 2:
        return stat

    # ── 分析表头 ──
    header_contexts = []
    first_row = rows[0]
    for tc in first_row.findall(f'{{{NS_W}}}tc'):
        label = get_text(tc).strip()
        ctx = detect_context(label)
        header_contexts.append((label, ctx))

    has_header_contexts = any(ctx is not None for _, ctx in header_contexts)

    # ── 如果没有明确的表头上下文，尝试把第一列当标签列 ──
    use_first_col_label = not has_header_contexts

    # ── 处理数据行 ──
    for row in rows[1:]:
        cells = row.findall(f'{{{NS_W}}}tc')
        if not cells:
            continue

        for ci, tc in enumerate(cells):
            cell_text = get_text(tc).strip()
            if not cell_text:
                continue

            context = None

            if use_first_col_label:
                # 第一列是标签 → 不改它，用它判断其他列上下文
                if ci == 0:
                    continue
                if cells:
                    first_label = get_text(cells[0]).strip()
                    context = detect_context(first_label)
            else:
                # 用表头判断
                if ci < len(header_contexts):
                    _, context = header_contexts[ci]

            if context:
                new_text, changed = force_by_context(cell_text, context)
                if changed:
                    set_text(tc, new_text)
                    stat['table_cells_changed'] += 1
                    stat[f'context_{context}'] += 1
            else:
                # 无上下文 → 仅对明显长数字脱敏（>=10位纯数字）
                digits = re.sub(r'\D', '', cell_text)
                if len(digits) >= 10:
                    new_text = re.sub(r'\d', '*', cell_text)
                    set_text(tc, new_text)
                    stat['table_cells_changed'] += 1
                    stat['long_num'] += 1

    return stat


# ─────────────────────────────────────────────
#  段落脱敏 (复用 sanitizer_engine)
# ─────────────────────────────────────────────

def process_paragraphs(root, rules_config):
    """对文档中所有 w:p 段落执行正则脱敏。返回 (changed_count, hit_count)"""
    from sanitizer_engine import sanitize_text

    changed = 0
    total_hits = 0

    # 找到 w:body
    body = root
    for child in root:
        tag = child.tag.split('}')[-1] if '}' in child.tag else child.tag
        if tag == 'body':
            body = child
            break

    for p in body.findall(f'{{{NS_W}}}p'):
        text = get_text(p)
        if not text or not text.strip():
            continue

        sanitized, replacements = sanitize_text(text, rules_config)
        if replacements:
            set_text(p, sanitized)
            changed += 1
            total_hits += len(replacements)

    return changed, total_hits


# ─────────────────────────────────────────────
#  XML 文件级处理
# ─────────────────────────────────────────────

def process_xml(xml_bytes, rules_config, xml_name=''):
    """处理单个 XML 文件（段落 + 表格），返回 (modified_bytes, stats)

    关键: 命名空间必须在解析前注册，序列化后才不会丢失 w: 等前缀。
    丢失前缀会导致 Word 报「发现无法读取的内容」。
    """
    stat = {
        'paragraphs_changed': 0,
        'paragraph_hits': 0,
        'table_cells_changed': 0,
        'context_email': 0,
        'context_phone': 0,
        'context_name': 0,
        'context_id': 0,
        'context_amount': 0,
        'context_address': 0,
        'long_num': 0,
    }

    # ── lxml 自动保留所有原始命名空间声明，无需手动注册 ──
    try:
        root = ET.fromstring(xml_bytes)
    except Exception:
        return xml_bytes, stat

    # 段落
    p_changed, p_hits = process_paragraphs(root, rules_config)
    stat['paragraphs_changed'] = p_changed
    stat['paragraph_hits'] = p_hits

    # 表格
    for tbl in root.findall(f'.//{{{NS_W}}}tbl'):
        tbl_stat = process_table(tbl)
        for k, v in tbl_stat.items():
            stat[k] += v

    changed = (p_changed > 0 or stat['table_cells_changed'] > 0)

    if changed:
        # 仅当原始 XML 有声明时才保留声明
        raw_str = xml_bytes.decode('utf-8')
        has_decl = raw_str.lstrip().startswith('<?xml')
        xml_bytes = ET.tostring(root, encoding='utf-8', xml_declaration=has_decl)

    return xml_bytes, stat


# ─────────────────────────────────────────────
#  统计 & 主入口
# ─────────────────────────────────────────────

def count_docx_text_chars(src):
    """统计 DOCX 内所有可读文本字符数"""
    total = 0
    with zipfile.ZipFile(src, 'r') as zf:
        for name in zf.namelist():
            if name.startswith('word/') and name.endswith('.xml'):
                try:
                    root = ET.fromstring(zf.read(name))
                    for t in root.iter(f'{{{NS_W}}}t'):
                        if t.text:
                            total += len(t.text)
                except Exception:
                    pass
    return total


def sanitize_docx(src_path, dst_path, rules_config):
    """
    对 DOCX 执行脱敏，输出到 dst_path。

    返回: dict {
        'success': bool,
        'docx_text_chars': int,
        'changed_xml_files': int,
        'changed_xml_names': [str],
        'paragraphs_changed': int,
        'paragraph_hits': int,
        'table_cells_changed': int,
        'context_email': int,
        'context_phone': int,
        'context_name': int,
        'context_id': int,
        'context_amount': int,
        'context_address': int,
        'long_num': int,
        'total_hits': int,
    }
    """
    src = Path(src_path)
    dst = Path(dst_path)

    if not src.exists():
        return {'success': False, 'error': f'源文件不存在: {src}'}

    # 复制原文件
    shutil.copy2(src, dst)

    stats = {
        'success': False,
        'docx_text_chars': count_docx_text_chars(src),
        'changed_xml_files': 0,
        'changed_xml_names': [],
        'paragraphs_changed': 0,
        'paragraph_hits': 0,
        'table_cells_changed': 0,
        'context_email': 0,
        'context_phone': 0,
        'context_name': 0,
        'context_id': 0,
        'context_amount': 0,
        'context_address': 0,
        'long_num': 0,
    }

    with zipfile.ZipFile(src, 'r') as zin, \
         zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)

            if item.filename.startswith('word/') and item.filename.endswith('.xml'):
                data, xml_stat = process_xml(data, rules_config, item.filename)

                if (xml_stat['paragraphs_changed'] > 0 or
                        xml_stat['table_cells_changed'] > 0):
                    stats['changed_xml_files'] += 1
                    stats['changed_xml_names'].append(item.filename)
                    stats['paragraphs_changed'] += xml_stat['paragraphs_changed']
                    stats['paragraph_hits'] += xml_stat['paragraph_hits']
                    stats['table_cells_changed'] += xml_stat['table_cells_changed']
                    stats['context_email'] += xml_stat['context_email']
                    stats['context_phone'] += xml_stat['context_phone']
                    stats['context_name'] += xml_stat['context_name']
                    stats['context_id'] += xml_stat['context_id']
                    stats['context_amount'] += xml_stat['context_amount']
                    stats['context_address'] += xml_stat['context_address']
                    stats['long_num'] += xml_stat['long_num']

            zout.writestr(item, data)

    stats['total_hits'] = (
        stats['paragraph_hits']
        + stats['context_email'] + stats['context_phone']
        + stats['context_name'] + stats['context_id']
        + stats['context_amount'] + stats['context_address']
        + stats['long_num']
    )
    stats['success'] = dst.exists() and dst.stat().st_size > 0

    return stats
